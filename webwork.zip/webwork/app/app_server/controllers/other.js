/* GET home page */
module.exports.about = function(req, res){
    res.render('generic-text', { 
        title: 'About time',
        content: "let God lead us"

});
};

module.exports.angularApp = function(req, res){
    res.render('layout', { title: 'here' });
};